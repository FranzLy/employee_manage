/*
 * ut.h
 *
 *  Created on: 2022年6月6日
 *      Author: Sangfor
 */

#ifndef UT_UT_H_
#define UT_UT_H_

typedef void (*fn_do_test)(void);
typedef void (*fn_setUp)(void);
typedef void (*fn_tearDown)(void);

//  注册测试套件的init函数
void ut_register_suite_init(const char* suitename, fn_setUp pfn);

//  注册测试套件的fini函数
void ut_register_suite_fini(const char* suitename, fn_tearDown pfn);

//  注册测试套件的setup函数
void ut_register_setup(const char* suitename, fn_setUp pfn);

//  注册测试套件的tearDown函数
void ut_register_teardown(const char* suitename, fn_tearDown pfn);

//  注册一个testcase到suite中
void ut_register_testcase(const char* suitename, const char* casename, fn_do_test pfn);

void ut_pack_expect_err(const char* fname, int line, const char* fmt, ...);

//  清理单元测试案例
void ut_clear_suites(void);

//  通过命令行参数方式启动单元测试
int ut_run_args(int argc, const char* argv[]);

#define SUITE_INIT(suitename)                                \
static void suite_init_##suitename##_fun(void);              \
__attribute__((constructor))                                 \
static void suite_init_##suitename##_CONSTRUCT(void) {       \
    ut_register_suite_init(#suitename, suite_init_##suitename##_fun);      \
}                                                            \
void suite_init_##suitename##_fun(void)

//  设置suite的tearDown函数
#define SUITE_FINI(suitename)                                \
static void suite_fini_##suitename##_fun(void);              \
__attribute__((constructor))                                 \
static void suite_fini_##suitename##_CONSTRUCT(void) {       \
    ut_register_suite_fini(#suitename, suite_fini_##suitename##_fun);      \
}                                                            \
void suite_fini_##suitename##_fun(void)


//  设置suite的setUp函数
#define SETUP(suitename)                                     \
static void setup_##suitename##_fun(void);                   \
__attribute__((constructor))                                 \
static void setup_##suitename##_CONSTRUCT(void) {            \
    ut_register_setup(#suitename, setup_##suitename##_fun);      \
}                                                            \
void setup_##suitename##_fun(void)

//  设置suite的tearDown函数
#define TEARDOWN(suitename)                                  \
static void teardown_##suitename##_fun(void);                \
__attribute__((constructor))                                 \
static void teardown_##suitename##_CONSTRUCT(void) {         \
    ut_register_teardown(#suitename, teardown_##suitename##_fun);\
}                                                            \
void teardown_##suitename##_fun(void)

//  定义一个测试案例
#define TEST(suitename, casename)                            \
static void testcase_##suitename##_##casename##_fun(void);           \
__attribute__((constructor))                                 \
static void testcase_##suitename##_##casename##_CONSTRUCT(void) {\
    ut_register_testcase(#suitename, #casename,           \
                         testcase_##suitename##_##casename##_fun);     \
}                                                            \
void testcase_##suitename##_##casename##_fun(void)

//  预期-表达式为真
#define EXPECT_TRUE(expr_)                                                  \
    do {                                                                    \
        if (!(expr_)) {                                                     \
            ut_pack_expect_err(__FILE__, __LINE__,                          \
                "\n\texpress: EXPECT_TRUE(%s)\n\texpect: true\n\tactual: false", #expr_);\
        }                                                                   \
    } while (0)
#endif /* UT_UT_H_ */
