/*
 * ut.c
 *
 *  Created on: 2022年6月6日
 *      Author: Sangfor
 */
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdarg.h>
#include "list.h"
#include "ut.h"

typedef struct _ut_case {
    struct list_head    list;
    const char         *name;       //测试名字
    void               *parent;
    fn_do_test          do_test;
    int32_t             state;
} ut_case_t;

typedef struct _ut_suite {
    struct list_head    list;
    const char         *name;       //测试集名字
    fn_setUp            setup;
    fn_tearDown         teardown;
    fn_setUp            init;
    fn_tearDown         fini;
    struct list_head    ut_child_head;
    int32_t             ut_child_cnt;
    int32_t             ut_child_failed_cnt;
} ut_suite_t;

static struct list_head s_suite_list = LIST_HEAD_INIT(s_suite_list);
static ut_case_t *s_curr_case = NULL;

static void
ut_case_free (ut_case_t *ucase)
{
    assert(ucase);
    free(ucase);
}

static ut_case_t*
ut_case_get_or_create (ut_suite_t *suite, const char* casename)
{
    ut_case_t *ucase = NULL;

    assert(suite && casename);

    list_for_each_entry(ucase, &suite->ut_child_head, list) {
        if (0 == strcmp(casename, ucase->name)) {
            return ucase;
        }
    }

    ucase = calloc(1, sizeof(*ucase));
    assert(ucase);

    ucase->name = casename;
    list_add_tail(&ucase->list, &suite->ut_child_head);
    suite->ut_child_cnt++;

    return ucase;
}

static void
ut_suite_free(ut_suite_t *suite)
{
    ut_case_t *ucase = NULL;
    ut_case_t *unext = NULL;

    assert(suite);
    list_for_each_entry_safe(ucase, unext, &suite->ut_child_head, list) {
        list_del_init(&ucase->list);
        ut_case_free(ucase);
    }

    free(suite);
}

void ut_clear_suites(void)
{
    ut_suite_t *suite = NULL;
    ut_suite_t *snext = NULL;

    list_for_each_entry_safe(suite, snext, &s_suite_list, list) {
        list_del_init(&suite->list);
        ut_suite_free(suite);
    }
}

static void ut_case_run (ut_suite_t *suite, ut_case_t *ucase)
{
    assert(suite && ucase);

    if (suite->setup)
        suite->setup();

    s_curr_case = ucase;
    ucase->do_test();

    if (suite->teardown)
        suite->teardown();
}

void ut_case_set_failed(void)
{
    s_curr_case->state = 1;
    ((ut_suite_t*)(s_curr_case->parent))->ut_child_failed_cnt++;
}

static void ut_suite_run(ut_suite_t *suite)
{
    ut_case_t *ucase = NULL;
    assert(suite);

    if (suite->init)
        suite->init();

    list_for_each_entry(ucase, &suite->ut_child_head, list) {
        ut_case_run(suite, ucase);
        printf("[CASE] %s   RESULT: %s\n", ucase->name, ucase->state ? "FAIL" : "SUCC");

        if (ucase->state)
            suite->ut_child_failed_cnt++;
    }

    if (suite->fini)
        suite->fini();
}

static ut_suite_t*
ut_suite_get_or_create (const char* suitename)
{
    ut_suite_t *suite = NULL;

    list_for_each_entry(suite, &s_suite_list, list) {
        if (0 == strcmp(suitename, suite->name)) {
            return suite;
        }
    }

    suite = calloc(1, sizeof(*suite));
    assert(suite);

    suite->name = suitename;
    INIT_LIST_HEAD(&suite->ut_child_head);

    list_add_tail(&suite->list, &s_suite_list);

    return suite;
}

void ut_register_testcase(const char* suitename, const char* casename, fn_do_test pfn)
{
    ut_case_t *ucase = NULL;
    ut_suite_t *suite = NULL;

    assert(suitename && casename && pfn);
    suite = ut_suite_get_or_create(suitename);
    assert(suite);

    ucase = ut_case_get_or_create(suite, casename);
    assert(ucase);

    ucase->do_test = pfn;
}

void ut_register_suite_init(const char* suitename, fn_setUp pfn)
{
    ut_suite_t *suite = NULL;

    assert(suitename && pfn);
    suite = ut_suite_get_or_create(suitename);
    assert(suite);

    suite->init = pfn;
}

void ut_register_suite_fini(const char* suitename, fn_tearDown pfn)
{
    ut_suite_t *suite = NULL;

    assert(suitename && pfn);
    suite = ut_suite_get_or_create(suitename);
    assert(suite);

    suite->fini = pfn;
}

void ut_register_setup(const char* suitename, fn_setUp pfn)
{
    ut_suite_t *suite = NULL;

    assert(suitename && pfn);
    suite = ut_suite_get_or_create(suitename);
    assert(suite);

    suite->setup = pfn;
}

void ut_register_teardown(const char* suitename, fn_tearDown pfn)
{
    ut_suite_t *suite = NULL;

    assert(suitename && pfn);
    suite = ut_suite_get_or_create(suitename);
    assert(suite);

    suite->teardown = pfn;
}

void ut_pack_expect_err(const char* fname, int line, const char* fmt, ...)
{
    va_list ap;

    s_curr_case->state++;

    printf("%s:%d", fname, line);
    va_start(ap, fmt);
    vprintf(fmt, ap);
    va_end(ap);
    printf("\n");
}

int ut_run_args(int argc, const char* argv[])
{
    ut_suite_t *suite = NULL;
    int         total_case = 0;
    int         failed_case = 0;

    list_for_each_entry(suite, &s_suite_list, list) {
        printf("--------------%s---------------\n", suite->name);

        ut_suite_run(suite);

        printf("[SUITE RESULT] test case: %d failed: %d\n",
                suite->ut_child_cnt, suite->ut_child_failed_cnt);

        total_case += suite->ut_child_cnt;
        failed_case += suite->ut_child_failed_cnt;
    }

    printf("----------------------------------------\n");
    printf("[RESULT] test case: %d failed: %d\n", total_case, failed_case);
    return 0;
}
