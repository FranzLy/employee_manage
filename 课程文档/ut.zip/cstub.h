#pragma once

#include <dlfcn.h>

#ifdef __cplusplus
extern "C" {
#endif
    int uninstall_stub(void* stub_f);
    int install_stub(void *orig_f, void *stub_f, char *desc);
    int stub_is_empty(void);
    void uninstall_all_stub();

#define INSTALL_STUB(o,s) install_stub((void*)o,(void*)s,(char*)#o"->"#s)
#define REMOVE_STUB(s) uninstall_stub((void*)s)

#define INSTALL_LIB_STUB(o,s) install_stub(dlsym(RTLD_NEXT, #o),(void*)s,(char*)#o"->"#s)
#define REMOVE_LIB_STUB(s) uninstall_stub(dlsym(RTLD_NEXT, #s))

#ifdef __cplusplus
}
#endif
