#include <sys/mman.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include "list.h"

#define _PAGESIZE 4096

static struct list_head g_stub_list = {&g_stub_list, &g_stub_list};
static pthread_mutex_t  g_stub_lock = PTHREAD_MUTEX_INITIALIZER;

struct stub
{
    struct list_head node;
    char             desc[256];
    void             *orig_f;
    void             *stub_f;
    unsigned int     stubpath;
    unsigned int     old_flg;
    unsigned char    assm[14];
};


static int set_mprotect(struct stub* pstub)
{
    void *p;
	int   ret;

    p = (void*)((long)pstub->orig_f & ~(_PAGESIZE - 1));
	ret = mprotect(p, _PAGESIZE * 2, PROT_READ|PROT_WRITE|PROT_EXEC);

    return ret;
}

static int set_asm_jmp(struct stub* pstub)
{
    // unsigned int offset;
    /* 保存从原始函数地址开始的5个字节，因为之后我们会改写这块区域 */
    memcpy(pstub->assm, pstub->orig_f, sizeof(pstub->assm));
    // *((char*)pstub->orig_f) = 0xE9;/* 这个是相对跳转指令jmp */
    /**************************************************************
     *计算出桩函数与原始函数之间的相对地址，注意要减去jmp指令的
     *5个字节(0xE9加上一个4字节的相对地址)，然后用这条jmp指令，改写
     *原始函数地址开始的5个字节，这样调用原始函数，就会自动跳到桩函数
     **************************************************************/
    // offset = (unsigned int)((long)pstub->stub_f - ((long)pstub->orig_f + 5));
    // *((unsigned int*)((char*)pstub->orig_f + 1)) = offset;

    // 长跳转
    *((char*)pstub->orig_f) = 0xff;
    *((char*)pstub->orig_f + 1) = 0x25;
    *((char*)pstub->orig_f + 2) = 0x00;
    *((char*)pstub->orig_f + 3) = 0x00;
    *((char*)pstub->orig_f + 4) = 0x00;
    *((char*)pstub->orig_f + 5) = 0x00;

    memcpy((char*)pstub->orig_f + 6, &pstub->stub_f, sizeof(unsigned long));

    return 0;
}

static void restore_asm(struct stub* pstub)
{
    /* 恢复原始函数地址开始的5个字节 */
    memcpy(pstub->orig_f, pstub->assm, sizeof(pstub->assm));
}

int stub_is_exist(void *orig_f)
{
    struct stub *pstub;

    pthread_mutex_lock(&g_stub_lock);
    {
        list_for_each_entry(pstub, &g_stub_list, node) {
            if (pstub->orig_f == orig_f) {
                pthread_mutex_unlock(&g_stub_lock);
                return 1;
            }
        }
    }
    pthread_mutex_unlock(&g_stub_lock);

    return 0;
}

int install_stub(void *orig_f, void *stub_f, char *desc)
{
    struct stub *pstub;
    int          ret;

    assert(orig_f);
    assert(stub_f);
    assert(desc);
    assert(!stub_is_exist(orig_f));

    pstub = (struct stub*)malloc(sizeof(*pstub));
    assert(pstub);

    pstub->orig_f = orig_f;
    pstub->stub_f = stub_f;
    strncpy(pstub->desc, desc, sizeof(pstub->desc));

    /* 设置该内存段属性 */
    ret = set_mprotect(pstub);
    assert(0 == ret);

    /* 用jmp指令去覆盖orig_f开始的5个字节 */
    ret = set_asm_jmp(pstub);
    assert(0 == ret);

    pthread_mutex_lock(&g_stub_lock);
    {
        list_add(&pstub->node, &g_stub_list);
    }
    pthread_mutex_unlock(&g_stub_lock);

    return 0;
}

int uninstall_stub(void* orig_f)
{
    struct stub         *pstub;

    assert(orig_f);

    /* 移除桩函数就是将原始函数地址开始的5个字节恢复，然后将该
     * * 函数的信息从链表中移除同时释放之前动态申请的内存 */
    list_for_each_entry(pstub, &g_stub_list, node)
    {
        if (pstub->orig_f == orig_f)
        {
            restore_asm(pstub);

            pthread_mutex_lock(&g_stub_lock);
            {
                list_del(&pstub->node);
            }
            pthread_mutex_unlock(&g_stub_lock);

            free(pstub);
            return 0;
        }
    }

    //解桩失败core掉
    abort();
    return -1;
}

int stub_is_empty(void)
{
    return (list_empty(&g_stub_list));
}

void uninstall_all_stub()
{
    struct stub         *pstub;
    struct stub         *next_stub;

    /* 移除桩函数就是将原始函数地址开始的5个字节恢复，然后将该
     * * 函数的信息从链表中移除同时释放之前动态申请的内存 */
    list_for_each_entry_safe(pstub, next_stub, &g_stub_list, node)
    {
            restore_asm(pstub);

            pthread_mutex_lock(&g_stub_lock);
            {
                list_del(&pstub->node);
            }
            pthread_mutex_unlock(&g_stub_lock);

            free(pstub);
    }
}