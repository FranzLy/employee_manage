#include <stdio.h>
#include <assert.h>
#include <errno.h>
#include "list_fast.c"
#include "xtest.h"

//  完成使用场景的测试
TEST(test, new)
{   
    list_fast_t         *flist              = NULL;
    
    flist = list_fast_new(0);
    EXPECT_TRUE(flist);
    EXPECT_TRUE(flist->bucket);
    EXPECT_EQ(LIST_FAST_BUCKET, flist->size);
    list_fast_free(flist);
    
    flist = list_fast_new(1024);
    EXPECT_TRUE(flist);
    EXPECT_TRUE(flist->bucket);
    EXPECT_EQ(1024, flist->size);
    list_fast_free(flist);

    flist = list_fast_new(10240);
    EXPECT_TRUE(flist);
    EXPECT_TRUE(flist->bucket);
    EXPECT_EQ(LIST_FAST_BUCKET, flist->size);
    list_fast_free(flist);
}

//  完成使用场景的测试
TEST(test, get)
{   
    list_fast_t         *flist              = NULL;
    list_fast_iterator_t *fit               = NULL;
    list_fast_iterator_t *fit2              = NULL;
    
    flist = list_fast_new(1024);
    ASSERT_TRUE(flist);

    fit = list_fast_get(NULL, 0);
    EXPECT_FALSE(fit);

    fit = list_fast_get(flist, 0);
    EXPECT_TRUE(fit);

    fit2 = list_fast_get(flist, 1023);
    EXPECT_TRUE(fit2);
    EXPECT_TRUE(fit != fit2);

    fit2 = list_fast_get(flist, 1024);
    EXPECT_TRUE(fit == fit2);

    list_fast_free(flist);
}

static int get_fn(void *data, void *ud)
{
    return 0;
}

//  完成使用场景的测试
TEST(test, find)
{ 
    char                *data               = NULL; 
    list_fast_t         *flist              = NULL;
    list_fast_iterator_t *fit               = NULL;
    list_fast_iterator_t *fit2              = NULL;
    
    flist = list_fast_new(1024);
    ASSERT_TRUE(flist);

    fit = list_fast_find(NULL, NULL, NULL);
    EXPECT_FALSE(fit);

    fit = list_fast_find(flist, NULL, NULL);
    EXPECT_FALSE(fit);

    fit = list_fast_find(flist, get_fn, NULL);
    EXPECT_FALSE(fit);    

    fit = list_fast_get(flist, 0);
    EXPECT_TRUE(fit);

    data = (char*)malloc(10);
    ASSERT_TRUE(data);
    strncpy(data, "abcdfe", sizeof(data) -1);

    fit2 = list_fast_iter_insert_after(fit, data);
    EXPECT_TRUE(fit2);
    EXPECT_TRUE(fit2->data);
    EXPECT_EQ(0, strcmp(fit2->data, data));
    
    fit = list_fast_find(flist, get_fn, NULL);
    EXPECT_TRUE(fit);    
    EXPECT_TRUE(fit->data);
    EXPECT_TRUE(fit == fit2);
    
    list_fast_free(flist);
    free(data);
}

//  完成使用场景的测试
TEST(test, foreach)
{ 
    char                *data               = NULL; 
    list_fast_t         *flist              = NULL;
    list_fast_iterator_t *fit               = NULL;
    list_fast_iterator_t *fit2              = NULL;
    
    flist = list_fast_new(1024);
    ASSERT_TRUE(flist);

    fit = list_fast_foreach(NULL, NULL, NULL);
    EXPECT_FALSE(fit);

    fit = list_fast_foreach(flist, NULL, NULL);
    EXPECT_FALSE(fit);

    fit = list_fast_foreach(flist, get_fn, NULL);
    EXPECT_FALSE(fit);    

    fit = list_fast_get(flist, 0);
    EXPECT_TRUE(fit);

    data = (char*)malloc(10);
    ASSERT_TRUE(data);
    strncpy(data, "abcdfe", sizeof(data) -1);

    fit2 = list_fast_iter_insert_after(fit, data);
    EXPECT_TRUE(fit2);
    EXPECT_TRUE(fit2->data);
    EXPECT_EQ(0, strcmp(fit2->data, data));
    
    fit = list_fast_foreach(flist, get_fn, NULL);
    EXPECT_TRUE(fit);    
    EXPECT_TRUE(fit->data);
    EXPECT_TRUE(fit == fit2);
    
    list_fast_free(flist);
    free(data);
}

TEST(test, insert_before)
{ 
    char                *data               = NULL; 
    list_fast_t         *flist              = NULL;
    list_fast_iterator_t *fit               = NULL;
    list_fast_iterator_t *fit2              = NULL;
    
    flist = list_fast_new(1024);
    ASSERT_TRUE(flist);

    fit = list_fast_get(flist, 0);
    EXPECT_TRUE(fit);

    data = (char*)malloc(10);
    ASSERT_TRUE(data);
    strncpy(data, "abcdfe", sizeof(data) -1);

    fit2 = list_fast_iter_insert_before(NULL, NULL);
    EXPECT_FALSE(fit2);

    fit2 = list_fast_iter_insert_before(fit, NULL);
    EXPECT_FALSE(fit2);

    fit2 = list_fast_iter_insert_before(NULL, data);
    EXPECT_FALSE(fit2);

    fit2 = list_fast_iter_insert_before(fit, data);
    EXPECT_TRUE(fit2);
    EXPECT_TRUE(fit2->data);
    EXPECT_EQ(0, strcmp(fit2->data, data));
    
    fit2 = list_fast_iter_forward(fit);
    EXPECT_TRUE(fit2);
    EXPECT_TRUE(fit2->data);
    EXPECT_EQ(0, strcmp(fit2->data, data));
    
    list_fast_free(flist);
    free(data);
}

TEST(test, insert_after)
{ 
    char                *data               = NULL;  
    list_fast_t         *flist              = NULL;
    list_fast_iterator_t *fit               = NULL;
    list_fast_iterator_t *fit2              = NULL;
    
    flist = list_fast_new(1024);
    ASSERT_TRUE(flist);

    fit = list_fast_get(flist, 0);
    EXPECT_TRUE(fit);

    data = (char*)malloc(10);
    ASSERT_TRUE(data);
    strncpy(data, "abcdfe", sizeof(data) -1);

    fit2 = list_fast_iter_insert_after(NULL, NULL);
    EXPECT_FALSE(fit2);

    fit2 = list_fast_iter_insert_after(fit, NULL);
    EXPECT_FALSE(fit2);

    fit2 = list_fast_iter_insert_after(NULL, data);
    EXPECT_FALSE(fit2);

    fit2 = list_fast_iter_insert_after(fit, data);
    EXPECT_TRUE(fit2);
    EXPECT_TRUE(fit2->data);
    EXPECT_EQ(0, strcmp(fit2->data, data));
    
    fit2 = list_fast_iter_next(fit);
    EXPECT_TRUE(fit2);
    EXPECT_TRUE(fit2->data);
    EXPECT_EQ(0, strcmp(fit2->data, data));
    
    list_fast_free(flist);
    free(data);
}

TEST(test, insert_set)
{ 
    char                *data               = NULL; 
    char                *data2              = NULL; 
    char                *data3              = NULL; 
    list_fast_t         *flist              = NULL;
    list_fast_iterator_t *fit               = NULL;
    list_fast_iterator_t *fit2              = NULL;
    
    flist = list_fast_new(1024);
    ASSERT_TRUE(flist);

    fit = list_fast_get(flist, 0);
    EXPECT_TRUE(fit);

    data = (char*)malloc(10);
    ASSERT_TRUE(data);
    strncpy(data, "abcdfe", sizeof(data) -1);

    data2 = (char*)malloc(10);
    ASSERT_TRUE(data);
    strncpy(data, "123123", sizeof(data) -1);

    fit2 = list_fast_iter_insert_after(fit, data);
    EXPECT_TRUE(fit2);
    EXPECT_TRUE(fit2->data);
    EXPECT_EQ(0, strcmp(fit2->data, data));
    
    data3 = list_fast_iter_data(fit2);
    EXPECT_TRUE(data3);
    EXPECT_EQ(0, strcmp(data3, data));

    list_fast_iter_set(fit2, data2);
    data3 = list_fast_iter_data(fit2);
    EXPECT_TRUE(data3);
    EXPECT_EQ(0, strcmp(data3, data2));
    
    list_fast_iter_clear(fit2);
    data3 = list_fast_iter_data(fit2);
    EXPECT_FALSE(data3);
    
    list_fast_free(flist);
    free(data);
    free(data2);
}

int main(int argc, char **argv)
{
    return xtest_start_test(argc, argv);
}

